package za.co.wethinkcode.models;

import java.awt.List;

import za.co.wethinkcode.Map.Map;
import za.co.wethinkcode.heroes.Hero;
import za.co.wethinkcode.heroes.HeroFactory;
// import za.co.wethinkcode.GameState;

public class GameModel {
	private Hero player;
	private Enum GameState;
	/* array list */
	private List<Villain>Villains;
	/* don't think i need this */
	private List<Artefac>Artefacs;
	private Map map;

/* 	public GameModel( GameController gameController)  {

	} */
	
}