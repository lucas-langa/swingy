//package za.co.wethinkcode.heroes;
//import za.co.wethinkcode.Map;
//
//public static class MoveHero {
//	public static void     moveUp(int currentY, int currentX, Map map){
//			map[currentY][currentX] = '*';
//			currentY -= 1;
//			map[currentY][currentX] = 'h';
//	}
//
//	public static void     moveDown(int currentY, int currentX){
//			map[currentY][currentX] = '*';
//			currentY += 1;
//			map[currentY][currentX] = 'h';
//	}
//
//	public static void     left(int currentY, int currentX){
//			map[currentY][currentX] = '*';
//			currentX -= 1;
//			map[currentY][currentX] = 'h';
//	}
//
//	public static void     right(int currentY, int currentX){
//			map[currentY][currentX] = '*';
//			currentX += 1;
//			map[currentY][currentX] = 'h';
//	}
//}