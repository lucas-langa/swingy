package za.co.wethinkcode;
import za.co.wethinkcode.controllers.HeroController;

import za.co.wethinkcode.models.HeroModel;
import za.co.wethinkcode.views.HeroView;


public class Swingy{
	public static void main( String [] args ) {
		HeroView theView = new HeroView();
		HeroModel theModel = new HeroModel();
		HeroController heroController = new HeroController(theView, theModel);
		theView.setVisible(true);
	}
}