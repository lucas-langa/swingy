package za.co.wethinkcode.controllers;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import za.co.wethinkcode.models.GameModel;
import za.co.wethinkcode.views.GameView;

public class GameController {
	private GameView theView;
	private GameModel theModel;


	public GameController( GameView theView, GameModel theModel){
		this.theModel = theModel;
		this.theView = theView;
		this.theView.addSaveGameListener( new saveGameListener());
	}

	class saveGameListener implements ActionListener{
		public void actionPerformed( ActionEvent arg0 ) {
		
			String GameName, GameClass;
			try {
				GameName = theView.getGameName();
				GameClass = theView.getGameClass();

				theModel.createGame(GameName, GameClass);
				theView.DisplayGame(theModel.getGame());				
			} catch (Exception e) {
				theView.displayErrorMessage(e.getMessage());
			}
			
		}
	}
}