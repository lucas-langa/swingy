package za.co.wethinkcode.GameState;

public enum GameState{
	START,
	PLAYING,
	WON,
	LOST,
	OVER;
}