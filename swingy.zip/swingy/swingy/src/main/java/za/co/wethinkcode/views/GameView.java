package za.co.wethinkcode.views;

import java.awt.event.ActionListener;

import javax.swing.*;

import za.co.wethinkcode.Gamees.Game;

public class GameView extends JFrame {
	private static final long serialVersionUID = -7423197113396448367L;
	private JLabel GameNameLabel = new JLabel("Game name");
	private JLabel GameClassLabel = new JLabel("Game class");
	private JTextField GameName = new JTextField(5);
	private JTextField GameClass = new JTextField(5);
	private JTextArea showGame = new JTextArea();
	private JButton saveGameButton = new JButton("Save");

	public GameView(){
		JPanel GamePanel = new JPanel();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(600, 600);

		GamePanel.add(GameNameLabel);
		GamePanel.add(GameName);
		GamePanel.add(GameClassLabel);
		GamePanel.add(GameClass);
		GamePanel.add(saveGameButton);

		this.add(GamePanel);
	}

	public String 	getGameName() {
		return ( GameName.getText() );
	}

	public String getGameClass() {
		return ( GameClass.getText() );
	}

	public void setGameName( String name ) {
		GameName.setText( name );
	}

	public void setGameClass( String hClass ){ 
		GameClass.setText( hClass );
	}

	public void 	addSaveGameListener( ActionListener listenerForSaveGameButton ) {
		saveGameButton.addActionListener( listenerForSaveGameButton );
	}

	public void 		DisplayGame( Game Game ) {
		showGame.setText(Game + "WTF");
		// System.out.println(Game + " WTF");
	}

	public void 		displayErrorMessage( String errorMessage ) {
		JOptionPane.showMessageDialog( this, errorMessage );
	}
}