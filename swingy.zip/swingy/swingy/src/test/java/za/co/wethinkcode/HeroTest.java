package za.co.wethinkcode;

import java.util.Set;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import za.co.wethinkcode.controllers.HeroController;
import za.co.wethinkcode.heroes.HeroFactory;
import za.co.wethinkcode.models.HeroModel;
import za.co.wethinkcode.views.HeroView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

public class HeroTest {
	private HeroModel heroModel;
	private HeroView heroView;
	
	@Before
	public void canCreateHero() {
		heroModel = new HeroModel();
		heroModel.createHero("lucas", "flanker");
		assertNotNull("Hero initialised", heroModel);
	}

	@Before
	public void canCreateHeroView() {
		heroView = new HeroView();
		assertNotNull("there ain't no views",heroView);
	}

	@Test
	public void canCreateHeroController(){

		HeroController heroController = new HeroController(this.heroView, this.heroModel);
		assertNotNull("no controllers ", heroController);
	}

	@Test
	public void canDisplayHero(){
		heroView.DisplayHero(heroModel.getHero());
	}


	@Test
	public void viewHasHeroName(){
		heroView.setHeroName("lucas");
		assertEquals("lucas", heroView.getHeroName());
	}

	@Test
	public void viewHasHeroClass() {
		heroView.setHeroClass("flanker");
		assertEquals("flanker", heroView.getHeroClass());
	}
}